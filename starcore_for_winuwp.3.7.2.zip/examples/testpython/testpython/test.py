from __future__ import division
print(division)

import sys
print(sys.path)
import zipfile
import os
print(os)
