function tt(a,b)
    print(a,b)
    return 6666,7777
end
g1 = 123
c={x=456}
function c:yy(a,b,z)
    print(self)
    print(a,b,z)
    return {33,Type="mytype"}
end  
  